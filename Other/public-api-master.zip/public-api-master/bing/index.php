<?php
date_default_timezone_set("PRC");
include('../curl.php');

$id = (isset($_GET["id"]) && $_GET["id"] >= -1 && $_GET["id"] <= 14) ? $_GET["id"] : 0;
if ($id == 0) {
    $today = json_decode(file_get_contents('today.json'), true);
    if ($today['date'] == date('Ymd', time())) {
        $url = $today['url'];
        $title = $today['title'];
        $date = $today['date'];
    } else {
        $bing = json_decode(curl_get('https://cn.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1'), true);
        $url = 'https://cn.bing.com'.$bing['images'][0]['url'];
        $title = $bing['images'][0]['copyright'];
        $date = $bing['images'][0]['enddate'];
        $today = array(
                'title' => $title,
                'date' => $date,
                'url' => $url
            );
        file_put_contents('today.json', json_encode($today, JSON_UNESCAPED_UNICODE));
    }
} else if ($id <= 7) {
    $bing = json_decode(curl_get('https://cn.bing.com/HPImageArchive.aspx?format=js&idx='.$id.'&n=1'), true);
    $url = 'https://cn.bing.com'.$bing['images'][0]['url'];
    $title = $bing['images'][0]['copyright'];
    $date = $bing['images'][0]['enddate'];
} else {
    $bing = json_decode(curl_get('https://cn.bing.com/HPImageArchive.aspx?format=js&idx=7&n=8'), true);
    $url = 'https://cn.bing.com'.$bing['images'][$id-7]['url'];
    $title = $bing['images'][$id-7]['copyright'];
    $date = $bing['images'][$id-7]['enddate'];
}

if (isset($_GET["format"]) && $_GET["format"] == 'json') {
    $result['code'] = 200;
    $result['msg'] = 'success';
    $result['title'] = 'Bing Daily Wallpaper';
    $result['data']['title'] = $title;
    $result['data']['date'] = $date;
    $result['data']['url'] = $url;
    header('Content-type:text/json');
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit();
} elseif (isset($_GET["format"]) && $_GET["format"] == 'url') {
    header('Content-type:text/plain');
    echo $url;
    exit();
} else {
    header('Location: '.$url);
    exit();
}

?>