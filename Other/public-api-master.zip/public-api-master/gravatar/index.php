<?php 

if((!isset($_GET['email']) || empty($_GET['email'])) && (!isset($_GET['md5']) || empty($_GET['md5']))) {
    header('HTTP/1.1 400 Bad Request');
    header('content-type:text/json');
    $result['code'] = 400;
    $result['msg'] = 'failed';
    $result['error'] = 'Please provide email or md5 hash value of email';
    $result['title'] = 'Gravatar';
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit();
}

include('../curl.php');

$md5 = empty($_GET['email'])?$_GET['md5']:md5(strtolower(trim($_GET['email'])));
$size = empty($_GET['size'])?80:$_GET['size'];
$cdn = empty($_GET['cdn'])?'hanada':$_GET['cdn'];
$default = empty($_GET['default'])?'mm':$_GET['default'];
$cdn_url = [
    "source" => "secure.gravatar.com/avatar/",
    "hanada" => "gravatar.hanada.info/avatar/",
    "v2ex" => "cdn.v2ex.com/gravatar/",
    "geekzu"=> "sdn.geekzu.org/avatar/",
];

if($_GET['format'] == 'json') {
    if(is_gravatar_exist($md5)) {
        $result['code'] = 200;
        $result['msg'] = 'success';
        $result['title'] = 'Gravatar';
        $result['url']= 'https://'.$cdn_url[$cdn].$md5.'?s='.$size.'&d='.$default;
    } else {
        $result['code'] = 200;
        $result['msg'] = 'error';
        $result['error'] = "No Gravatar for this email";
        $result['title'] = 'Gravatar';
        $result['url']= 'https://'.$cdn_url[$cdn].$md5.'?s='.$size.'&d='.$default;
    }
    header('content-type:text/json');
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
} elseif($_GET['format'] == 'url'){
    header('content-type:text/plain');
    echo 'https://'.$cdn_url[$cdn].$md5.'?s='.$size.'&d='.$default;
} else {
    header('Location: '.'https://'.$cdn_url[$cdn].$md5.'?s='.$size.'&d='.$default);
}

function is_gravatar_exist($md5) {
    $url = 'https://gravatar.hanada.info/avatar/'.$md5.'?d=404';
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HEADER, 1);
    curl_setopt($curl, CURLOPT_NOBODY,true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($curl);
    $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);
    if (404 == $httpcode) {
        return false;
    } else {
        return true;
    }
}