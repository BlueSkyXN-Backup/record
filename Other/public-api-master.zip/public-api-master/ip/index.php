<?php

include('../curl.php');

$ip = filter_var($_GET['ip'], FILTER_VALIDATE_IP) ? $_GET['ip'] : $_SERVER['REMOTE_ADDR'];
$ipver = filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ? 4 : 6;

if($_GET['format'] == 'ip') {
    $ip = $_SERVER['REMOTE_ADDR'];
    echo $ip;
    exit();
}

header('Content-type:text/json');
if($ipver == 6) {
    $database = 'ipv6';
    $ipip_arr[0] = '';
    $ipip_arr[1] = '';
    $ipip_arr[2] = '';
    $ipip_arr[3] = '';
    $ipip_arr[4] = '';
}elseif ($_GET['database'] === 'chunzhen') {
    include './chunzhenIP/chunzhenIP.php';
    $iplocation = new IpLocation();
    $chunzhen_arr = $iplocation->getlocation($ip);
    $database = 'chunzhen';
} else {
    $database = 'ipip';
    $ipip_arr = json_decode(curl_get('https://freeapi.ipip.net/'.$ip));
    if (!$ipip_arr[0]) {
        include './chunzhenIP/chunzhenIP.php';
        $iplocation = new IpLocation();
        $chunzhen_arr = $iplocation->getlocation($ip);
        $database = 'chunzhen';
    }
}

if ($database == 'ipip' || $database == 'ipv6') {
    $result['code'] = 200;
    $result['msg'] = 'success';
    $result['title'] = 'IP Location Parser';
    $result['database'] = $database;
    $result['ip'] = $ip;
    $result['ipver'] = $ipver;
    $result['location']['country'] = $ipip_arr[0];
    $result['location']['province'] = $ipip_arr[1];
    $result['location']['city'] = $ipip_arr[2];
    $result['location']['company'] = $ipip_arr[3];
    $result['location']['isp'] = $ipip_arr[4];
} else {
    if (preg_match('/北京|广东|山东|江苏|河南|上海|河北|浙江|香港|陕西|湖南|重庆|福建|天津|云南|四川|广西|安徽|海南|江西|湖北|山西|辽宁|台湾|黑龙江|内蒙古|澳门|贵州|甘肃|青海|新疆|西藏区|吉林|宁夏/', $chunzhen_arr['country'])) {
        $chunzhen_arr['country'] = '中国'.$chunzhen_arr['country'];
    }
    $result['code'] = 200;
    $result['msg'] = 'success';
    $result['title'] = 'IP Location Parser';
    $result['database'] = $database;
    $result['ip'] = $ip;
    $result['ipver'] = $ipver;
    $result['location']['country'] = preg_replace('/省|市|/', '', $chunzhen_arr['country']);
    $result['location']['isp'] = $chunzhen_arr['area'];
}

echo json_encode($result, JSON_UNESCAPED_UNICODE);
exit();

?>