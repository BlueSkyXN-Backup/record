<?php
$dataFile = 'data.php';
$handle = fopen($dataFile, 'r'); 
$bocData = unserialize(fread($handle,filesize($dataFile)));

if(empty($handle) || empty($bocData)){
    header('HTTP/1.1 500 Internal Server Error');
    header('content-type:text/json');
    $result['code'] = 500;
    $result['msg'] = 'failed';
    $result['error'] = "获取外汇牌价失败";
    $result['title'] = '中国银行外汇牌价';
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit();
}

$result['code'] = 200;
$result['msg'] = 'success';
$result['title'] = 'Bank of China CNY Exchange Rate';

switch ( strtoupper($_GET['currency']) ) {
    case 'AED':
        $resultAED = aed($bocData);
        $result = array_merge($result, $resultAED);
        break;
    case 'AUD':
        $resultAUD = aud($bocData);
        $result = array_merge($result, $resultAUD);
        break;
    case 'BRL':
        $resultBRL = brl($bocData);
        $result = array_merge($result, $resultBRL);
        break;
    case 'CAD':
        $resultCAD = cad($bocData);
        $result = array_merge($result, $resultCAD);
        break;
    case 'CHF':
        $resultCHF = chf($bocData);
        $result = array_merge($result, $resultCHF);
        break;
    case 'DKK':
        $resultDKK = dkk($bocData);
        $result = array_merge($result, $resultDKK);
        break;
    case 'EUR':
        $resultEUR = eur($bocData);
        $result = array_merge($result, $resultEUR);
        break;
    case 'GBP':
        $resultGBP = gbp($bocData);
        $result = array_merge($result, $resultGBP);
        break;
    case 'HKD':
        $resultHKD = hkd($bocData);
        $result = array_merge($result, $resultHKD);
        break;
    case 'IDR':
        $resultIDR = idr($bocData);
        $result = array_merge($result, $resultIDR);
        break;
    case 'INR':
        $resultINR = inr($bocData);
        $result = array_merge($result, $resultINR);
        break;
    case 'JPY':
        $resultJPY = jpy($bocData);
        $result = array_merge($result, $resultJPY);
        break;
    case 'KRW':
        $resultKRW = KRW($bocData);
        $result = array_merge($result, $resultKRW);
        break;
    case 'MOP':
        $resultMOP = mop($bocData);
        $result = array_merge($result, $resultMOP);
        break;
    case 'MYR':
        $resultMYR = myr($bocData);
        $result = array_merge($result, $resultMYR);
        break;
    case 'NOK':
        $resultNOK = nok($bocData);
        $result = array_merge($result, $resultNOK);
        break;
    case 'NZD':
        $resultNZD = nzd($bocData);
        $result = array_merge($result, $resultNZD);
        break;
    case 'PHP':
        $resultPHP = php($bocData);
        $result = array_merge($result, $resultPHP);
        break;
    case 'RUB':
        $resultRUB = rub($bocData);
        $result = array_merge($result, $resultRUB);
        break;
    case 'SAR':
        $resultSAR = sar($bocData);
        $result = array_merge($result, $resultSAR);
        break;
    case 'SEK':
        $resultSEK = sek($bocData);
        $result = array_merge($result, $resultSEK);
        break;
    case 'SGD':
        $resultSGD = sgd($bocData);
        $result = array_merge($result, $resultSGD);
        break;
    case 'THB':
        $resultTHB = thb($bocData);
        $result = array_merge($result, $resultTHB);
        break;
    case 'TRY':
        $resultTRY = try2($bocData);
        $result = array_merge($result, $resultTRY);
        break;
    case 'TWD':
        $resultTWD = twd($bocData);
        $result = array_merge($result, $resultTWD);
        break;
    case 'USD':
        $resultUSD = usd($bocData);
        $result = array_merge($result, $resultUSD);
        break;
    case 'ZAR':
        $resultZAR = zar($bocData);
        $result = array_merge($result, $resultZAR);
        break;
    default:
        $resultAll = all($bocData);
        $result = array_merge($result, $resultAll);
        break;
}

header('Content-type:text/json');
echo json_encode($result, JSON_UNESCAPED_UNICODE);

function all($bocData) {
    $resultAED = aed($bocData);
    $resultAUD = aud($bocData);
    $resultBRL = brl($bocData);
    $resultCAD = cad($bocData);
    $resultCHF = chf($bocData);
    $resultDKK = dkk($bocData);
    $resultEUR = eur($bocData);
    $resultGBP = gbp($bocData);
    $resultHKD = hkd($bocData);
    $resultIDR = idr($bocData);
    $resultINR = inr($bocData);
    $resultJPY = jpy($bocData);
    $resultKRW = krw($bocData);
    $resultMOP = mop($bocData);
    $resultMYR = myr($bocData);
    $resultNOK = nok($bocData);
    $resultNZD = nzd($bocData);
    $resultPHP = php($bocData);
    $resultRUB = rub($bocData);
    $resultSAR = sar($bocData);
    $resultSEK = sek($bocData);
    $resultSGD = sgd($bocData);
    $resultTHB = thb($bocData);
    $resultTRY = try2($bocData);
    $resultTWD = twd($bocData);
    $resultUSD = usd($bocData);
    $resultZAR = zar($bocData); 
    $result = array_merge($resultAED, $resultAUD, $resultBRL, $resultCAD, $resultCHF, $resultDKK, $resultEUR, $resultGBP, $resultHKD, $resultIDR, $resultINR, $resultJPY, $resultKRW, $resultMOP, $resultMYR, $resultNOK, $resultNZD, $resultPHP, $resultRUB, $resultSAR, $resultSEK, $resultSGD, $resultTHB, $resultTRY, $resultTWD, $resultUSD, $resultZAR);
    return $result;
}

function aed($bocData) {
    $currencyEN = 'AED';
    $number = 3;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function aud($bocData) {
    $currencyEN = 'AUD';
    $number = 4;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function brl($bocData) {
    $currencyEN = 'BRL';
    $number = 5;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function cad($bocData) {
    $currencyEN = 'CAD';
    $number = 6;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function chf($bocData) {
    $currencyEN = 'CHF';
    $number = 7;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function dkk($bocData) {
    $currencyEN = 'DKK';
    $number = 8;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function eur($bocData) {
    $currencyEN = 'EUR';
    $number = 9;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function gbp($bocData) {
    $currencyEN = 'GBP';
    $number = 10;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function hkd($bocData) {
    $currencyEN = 'HKD';
    $number = 11;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function idr($bocData) {
    $currencyEN = 'IDR';
    $number = 12;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function inr($bocData) {
    $currencyEN = 'INR';
    $number = 13;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function jpy($bocData) {
    $currencyEN = 'JPY';
    $number = 14;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function krw($bocData) {
    $currencyEN = 'KRW';
    $number = 15;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function mop($bocData) {
    $currencyEN = 'MOP';
    $number = 16;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function myr($bocData) {
    $currencyEN = 'MYR';
    $number = 17;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function nok($bocData) {
    $currencyEN = 'NOK';
    $number = 18;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function nzd($bocData) {
    $currencyEN = 'NZD';
    $number = 19;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function php($bocData) {
    $currencyEN = 'PHP';
    $number = 20;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function rub($bocData) {
    $currencyEN = 'RUB';
    $number = 21;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function sar($bocData) {
    $currencyEN = 'SAR';
    $number = 22;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function sek($bocData) {
    $currencyEN = 'SEK';
    $number = 23;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function sgd($bocData) {
    $currencyEN = 'SGD';
    $number = 24;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function thb($bocData) {
    $currencyEN = 'THB';
    $number = 25;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function try2($bocData) {
    $currencyEN = 'TRY';
    $number = 26;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function twd($bocData) {
    $currencyEN = 'TWD';
    $number = 27;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function usd($bocData) {
    $currencyEN = 'USD';
    $number = 28;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}

function zar($bocData) {
    $currencyEN = 'ZAR';
    $number = 29;
    $result = dataAnalysis($bocData, $number, $currencyEN);
    return $result;
}


function dataAnalysis($bocData, $number, $currencyEN){
    //设置币种
    $currencyCH = $bocData[$number][0];
    $currencyEN = $currencyEN;

    //获取汇率更新时间
    //$dateChina = $bocData[$number][6].' '.$bocData[$number][7];
    $dateChina = str_replace('.', '-', $bocData[$number][6]);
    $timestamp = strtotime($dateChina);
    $dateGMT = gmdate('Y-m-d H:i:s', $timestamp);


    $rate['buyingrate']['en'] = 'Buying Rate';
    $rate['cashbuyingrate']['en'] = 'Cash Buying Rate';
    $rate['sellingrate']['en'] = 'Selling Rate';
    $rate['cashsellingrate']['en'] = 'Cash Selling Rate';
    $rate['middlerate']['en'] = 'Middle Rate';
    
    $rate['buyingrate']['cn'] = '现汇买入价';
    $rate['cashbuyingrate']['cn'] = '现钞买入价';
    $rate['sellingrate']['cn'] = '现汇卖出价';
    $rate['cashsellingrate']['cn'] = '现钞卖出价';
    $rate['middlerate']['cn'] = '中行折算价';


    //获取汇率详情
    $rate['buyingrate']['value'] = (double) $bocData[$number][1];
    $rate['cashbuyingrate']['value'] = (double) $bocData[$number][2];
    $rate['sellingrate']['value'] = (double) $bocData[$number][3];
    $rate['cashsellingrate']['value'] = (double) $bocData[$number][4];
    $rate['middlerate']['value'] = (double) $bocData[$number][5];
    
    $result[$currencyEN]['currency']['cn'] = $currencyCH;
    $result[$currencyEN]['currency']['en'] = $currencyEN;
    $result[$currencyEN]['date']['timestamp'] = $timestamp;
    $result[$currencyEN]['date']['gmt'] = $dateGMT;
    $result[$currencyEN]['date']['gmt+8'] = $dateChina;
    $result[$currencyEN]['rate'] = $rate;
    
    return $result;
}



?>