<?php

include('../curl.php');

//获取汇率数据
$bocDataUrl = 'https://www.boc.cn/sourcedb/whpj/';
$bocData = getBocData($bocDataUrl);
if (!$bocData[3][0]) {
    echo '缓存失败(访问失败)';
    exit();
}

$dataFile = 'data.php';
if (false !== fopen($dataFile, 'w+')) {
    file_put_contents($dataFile, serialize($bocData));
    //写入缓存
    echo '缓存成功';
    exit();
} else {
    echo '缓存失败(写入失败)';
    exit();
}

function getBocData($url) {
    if ($str === '') {
        return false;
    }

    $fcontents = curl_get($url);
    $table_data = preg_match_all('/<table[^>]*>(.*?) <\/table>/si',$fcontents,$match);
    $table_data = $match[0][0];

    $table_array = explode('<tr>',$table_data);
    $data = array();

    for ($i = 2; $i < count($table_array); $i++) {
        $data[$i] = explode('</td>',$table_array[$i]);
        for ($j = 0;$j < count($data[$i]);
            $j++) {
            $data[$i][$j] = preg_replace('/\s(?=\s)/','',trim(strip_tags($data[$i][$j])));
        }
        array_pop($data[$i]);
    }
    return $data;
}