<?php 

if(!isset($_GET['url']) || empty($_GET['url'])) {
    header('HTTP/1.1 400 Bad Request');
    header('content-type:text/json');
    $result['code'] = 400;
    $result['msg'] = 'failed';
    $result['error'] = 'Please provide the url to be recovered';
    $result['title'] = 'Shorturl Recover to Longurl';
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit();
}

$url = $_GET['url'];
$header = get_headers($url, 1);
if (strpos($header[0],'301') || strpos($header[0],'302')) {
	if(is_array($header['Location'])) {
		$long_url = $header['Location'][count($header['Location'])-1];
	}else{
		$long_url = $header['Location'];
	}
}

if(empty($url)){
    header('content-type:text/json');
    $result['code'] = 200;
    $result['msg'] = 'error';
    $result['error'] = 'URL request failed';
    $result['title'] = 'Shorturl Recover to Longurl';
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit();
}


if($_GET['format'] == 'json'){
    header('content-type:text/json');
    $result['code'] = 200;
    $result['msg'] = 'success';
    $result['title'] = 'Shorturl Recover to Longurl';
    $result['shorturl'] = $_GET['url'];
    $result['longurl'] = $long_url;
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
} else{
    echo $long_url;
}