<?php

include('../curl.php');

$ua = urlencode(urldecode($_GET['ua']))?:urlencode($_SERVER['HTTP_USER_AGENT']);

$header['code'] = 200;
$header['msg'] = 'success';
$header['title'] = 'User-Agent Device Parser';
$header['useragent'] = urldecode($ua);
$ua_device = json_decode(file_get_contents('http://127.0.0.1:3000/ua/ua-device/?ua='.$ua), true);

if(empty($ua_device)){
    header('HTTP/1.1 500 Internal Server Error');
    header('content-type:text/json');
    $result['code'] = 500;
    $result['msg'] = 'failed';
    $result['error'] = "Failed to get device information";
    $result['title'] = 'User-Agent Device Parser';
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit();
}

unset($ua_device["options"]);
unset($ua_device["camouflage"]);
unset($ua_device["features"]);
unset($ua_device["device"]["identified"]);

$result = array_merge($header, $ua_device);
header('content-type:text/json');
echo json_encode($result, JSON_UNESCAPED_UNICODE);
exit();
?>