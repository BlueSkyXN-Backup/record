<?php


include('../curl.php');
include('../qr/phpqrcode.php');

if(!isset($_GET['url']) || empty($_GET['url'])) {
    header('HTTP/1.1 400 Bad Request');
    header('content-type:text/json');
    $result['code'] = 400;
    $result['msg'] = 'failed';
    $result['error'] = 'Please provide the URL used to generate the short URL';
    $result['title'] = 'Shorturl generate';
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit();
}

switch( $_GET['domain'] ) {
    case 'u.nu' :
        if (isset($_GET['keyword']) && !empty($_GET['keyword'])) {
            $getdata = curl_get('https://u.nu/api.php?action=shorturl&format=json&keyword='.$_GET['keyword'].'&url='.urlencode(urldecode($_GET['url'])));
        }else {
            $getdata = curl_get('https://u.nu/api.php?action=shorturl&format=json&url='.urlencode(urldecode($_GET['url'])));
        }
        $data = json_decode($getdata, true);
        if ( $data['statusCode'] == 200 && $data['shorturl']) {
            $shorturl = $data['shorturl'];
        }else if($data['code'] == 'error:keyword' && isset($_GET['keyword']) && !empty($_GET['keyword']) && $_GET['force'] == 'true' ) {
            $getdata = curl_get('https://u.nu/api.php?action=shorturl&format=json&url='.$_GET['url']);
            $data = json_decode($getdata, true);
            $shorturl = $data['shorturl'] ?: '';
        }else {
            $shorturl = '';
        }
        break;
    case 'dwz.cn' :
        $url = 'https://dwz.cn/admin/v2/create';
        $headers = array('Content-Type:application/json', 'Token:03e8a077704e72a1ebd7a5183217d536');
        $bodys = array('url' => urldecode($_GET['url']));
        $postdata = curl_post_json($url, $headers, json_encode($bodys));
        $data = json_decode($postdata, true);
        if (!empty($data['ShortUrl']) && !$data['Code'] ){
            $shorturl = $data['ShortUrl'];
        }else {
            $shorturl = '';
        }
        break;
    case 't.cn' :
        $getdata = curl_get('https://v1.alapi.cn/api/url?type=1&url='.urlencode(urldecode($_GET['url'])));
        $data = json_decode($getdata, true);
        $shorturl = $data['data']['short_url'] ? str_replace('http://', 'https://', $data['data']['short_url']) : '';
        break;
    case 'url.cn' :
        $getdata = curl_get('https://v1.alapi.cn/api/url?type=1&url='.urlencode(urldecode($_GET['url'])));
        $data = json_decode($getdata, true);
        $shorturl = $data['data']['short_url'];
        break;
    default:
        $getdata = curl_get('https://v1.alapi.cn/api/url?type=1&url='.urlencode(urldecode($_GET['url'])));
        $data = json_decode($getdata, true);
        $shorturl = $data['data']['short_url'] ? str_replace('http://', 'https://', $data['data']['short_url']) : '';
        break;
}

if(empty($shorturl)){
    header('HTTP/1.1 500 Internal Server Error');
    header('content-type:text/json');
    $result['code'] = 500;
    $result['msg'] = 'failed';
    $result['error'] = "Shorturl generating failed";
    $result['title'] = 'Shorturl generate';
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit();
}

if( $_GET['format'] == 'qrcode') {
    
    $errorLevel = (isset($_GET["err"]) && strlen($_GET["err"]) == 1 && preg_match('/L|M|Q|H/', $_GET["err"])) ? $_GET["err"] : 'M';
    $PointSize = '6';
    $margin = (isset($_GET["margin"]) && $_GET["margin"] >= 0 && $_GET["margin"] <= 10) ? $_GET["margin"] : '1';
    //调用二维码生成函数
    createqr($shorturl, $errorLevel, $PointSize, $margin);
    exit();
}else if( $_GET['format'] == 'json' ){
    header('content-type:text/json');
    $result['code'] = 200;
    $result['msg'] = 'success';
    $result['title'] = 'Shorturl generate';
    $result['domain'] - $_GET['domain'];
    $result['long_url'] = $_GET['url'];
    $result['short_url'] = $shorturl;
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
}else{
    header('Content-type:text/plain');
    echo $shorturl;
    exit();
}

//二维码生成函数
function createqr($value, $errorCorrectionLevel, $matrixPointSize, $margin) {
    QRcode::png($value, false, $errorCorrectionLevel, $matrixPointSize, $margin);
}

?>