<?php

function curl_get($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url); //设置URL
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); //设置超时时间10s
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //不直接输出结果
    $r = curl_exec($ch);
    if($r === false ){
        curl_close($ch);
        return '';
    }else {
        curl_close($ch);
        return $r;
    }
}

function curl_get_httpcode($url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url); //设置URL
	curl_setopt($ch, CURLOPT_TIMEOUT, 10); //设置超时时间5s
	curl_setopt($ch, CURLOPT_HEADER, true); //获取Header
	curl_setopt($ch,CURLOPT_NOBODY, true); //不获取Body
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //不直接输出结果
	$r = curl_exec($ch); 
	$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch); 
	return $code;
}

function curl_post_json($url, $headers, $bodys) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url); //设置URL
    curl_setopt($ch, CURLOPT_POST, true); //POST请求
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');//自定请求方式
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);//请求头类型
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); //设置超时时间5s
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //不直接输出结果
    curl_setopt($ch, CURLOPT_POSTFIELDS, $bodys); //POST数据
    $r = curl_exec($ch);
    if($r === false ){
        curl_close($ch);
        return '';
    }else {
        curl_close($ch);
        return $r;
    }
}