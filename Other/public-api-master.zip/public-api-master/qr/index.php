<?php

//载入qrcode类
include "./phpqrcode.php";
 
//取得GET参数
if ( isset($_GET["text"]) && $_GET["text"] != ''){
    if(strpos( urldecode($_GET['text']),'://')){
        $text = urldecode($_GET["text"]);
    }else {
        $text = $_GET["text"];
    }
}else{
    header('HTTP/1.1 400 Bad Request');
    header('content-type:text/json');
    $result['code'] = 400;
    $result['msg'] = 'failed';
    $result['error'] = 'Please provide the text or URL used to generate the QRCode';
    $result['title'] = 'QRCode generate';
    echo json_encode($result, JSON_UNESCAPED_UNICODE);
    exit();
}

$errorLevel = (isset($_GET["err"]) && strlen($_GET["err"]) == 1 && preg_match('/L|M|Q|H/', $_GET["err"])) ? $_GET["err"] : 'M';
$PointSize = (isset($_GET["point"]) && $_GET["point"] >= 1 && $_GET["point"] <= 10) ? $_GET["point"] : '6';
$margin = (isset($_GET["margin"]) && $_GET["margin"] >= 0 && $_GET["margin"] <= 10) ? $_GET["margin"] : '1';


//自定义的url过滤功能
//preg_match('/http:\/\/([\w\W]*?)\//si', $url, $matches);
//if ( $matches[1] != 'hanada.info' && $matches[1] != 'tamersunion.net' || $url == 'help') 


//调用二维码生成函数
createqr($text, $errorLevel, $PointSize, $margin);
exit();


//二维码生成函数
function createqr($value, $errorCorrectionLevel, $matrixPointSize, $margin) {
    QRcode::png($value, false, $errorCorrectionLevel, $matrixPointSize, $margin);
}

?>